const _ = require('underscore');
const array=["Java","Javascript","Typescript"];
const arr1=_.contains(array,"Java");
const arr2=_.contains(array,"C++");
console.log(arr1);
console.log(arr2);